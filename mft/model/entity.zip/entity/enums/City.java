package mft.model.entity.enums;

public enum City {
    Tehran,
    Shiraz,
    Mashhad,
    Isfahan,
    Tabriz
}
