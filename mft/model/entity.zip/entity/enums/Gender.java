package mft.model.entity.enums;

public enum Gender {
    Male,
    Female
}
